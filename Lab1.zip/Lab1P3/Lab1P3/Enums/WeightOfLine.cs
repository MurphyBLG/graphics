﻿namespace Lab1P3.Enums;

public enum WeightOfLine
{
    Five = 5,
    Ten = 10,
    Fifteen = 15
}