﻿namespace Lab1P3.Enums;

public enum TypeOfLine
{
    Solid = 1,
    Dotted = 2
}