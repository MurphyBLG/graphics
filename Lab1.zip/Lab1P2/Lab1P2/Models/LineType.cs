﻿namespace Lab1P2.Models;

public class LineType
{
    public string Name { get; set; } = null!;

}