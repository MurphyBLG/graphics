﻿namespace Lab1P2.Models;

public class GeometricFigure
{
    public string Name { get; set; }
    public GeometricFigure(string name)
    {
        Name = name;
    }
}